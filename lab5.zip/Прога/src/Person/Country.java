package Person;

public enum Country {
    USA,
    FRANCE,
    ITALY;
}
