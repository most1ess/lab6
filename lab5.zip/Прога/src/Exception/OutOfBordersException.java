package Exception;

public class OutOfBordersException extends Exception{
    public OutOfBordersException(String field) {
        System.out.println("Ошибка! Значение поля " + field + " одного из элементов имеет недопустимое значение!");
        System.out.println("Элемент с ошибочным значением поля и все последующие элементы не были загружены.");
    }
}
