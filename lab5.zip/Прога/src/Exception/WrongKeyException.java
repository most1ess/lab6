package Exception;

public class WrongKeyException extends Exception {
    public WrongKeyException() {
        System.out.println("Ключ не найден.");
    }
}
