package Exception;

public class ImpossibleToClearException {
    public ImpossibleToClearException() {
        System.out.println("Невозможно очистить коллекцию! Она уже чиста.");
    }
}
